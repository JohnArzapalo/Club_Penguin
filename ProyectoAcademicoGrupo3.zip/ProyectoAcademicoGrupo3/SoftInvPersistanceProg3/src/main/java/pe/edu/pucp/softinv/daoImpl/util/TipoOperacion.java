package pe.edu.pucp.softinv.daoImpl.util;

public enum TipoOperacion {
    INSERTAR, MODIFICAR, ELIMINAR
}